import React from 'react';
import './Dashboard.css';
import { adminState } from '../../../state/adminStore';

const Dashboard = () => {
  const today = new Date().toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });

  const mockActivity = [
    { id: 'ORD-892A', patient: 'Elena Rostova', medicine: 'Amoxicillin 500mg', status: 'COMPLETED', time: '10:42 AM' },
    { id: 'ORD-892B', patient: 'Marcus Chen', medicine: 'Lisinopril 10mg', status: 'PENDING', time: '11:15 AM' },
    { id: 'ORD-892C', patient: 'Sarah Jenkins', medicine: 'Metformin 850mg', status: 'COMPLETED', time: '11:30 AM' },
    { id: 'ORD-892D', patient: 'David Okafor', medicine: 'Atorvastatin 20mg', status: 'REJECTED', time: '12:05 PM' },
    { id: 'ORD-892E', patient: 'Priya Sharma', medicine: 'Levothyroxine 50mcg', status: 'PENDING', time: '12:45 PM' }
  ];

  return (
    <div className="admin-dashboard">
      <div className="admin-page-header">
        <div className="admin-page-title-row">
          <h1 className="admin-page-title">DASHBOARD</h1>
          <span className="admin-user">{adminState.adminUser || 'admin'}</span>
        </div>
        <div className="admin-page-date">{today}</div>
      </div>

      <div className="dashboard-stats-grid">
        <div className="stat-card">
          <div className="stat-label">TOTAL ORDERS</div>
          <div className="stat-value">142</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">PENDING ORDERS</div>
          <div className="stat-value">7</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">LOW STOCK ITEMS</div>
          <div className="stat-value">4</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">PATIENTS TODAY</div>
          <div className="stat-value">23</div>
        </div>
      </div>

      <div className="dashboard-activity">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ORDER ID</th>
              <th>PATIENT</th>
              <th>MEDICINE</th>
              <th>STATUS</th>
              <th>TIME</th>
            </tr>
          </thead>
          <tbody>
            {mockActivity.map((row) => (
              <tr key={row.id}>
                <td>{row.id}</td>
                <td>{row.patient}</td>
                <td>{row.medicine}</td>
                <td className={`status-${row.status.toLowerCase()}`}>{row.status}</td>
                <td>{row.time}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
